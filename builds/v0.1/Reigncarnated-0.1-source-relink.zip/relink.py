#!/usr/bin/env python3
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--ndk',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--decoder-libs',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent;out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
results={}
for name,command in json.loads((root/'link-commands.json').read_text()).items():
 args=[]
 for token in command:
  if a.decoder_libs and token.startswith('decoder-lib/'):token=str(a.decoder_libs.resolve()/Path(token).name)
  args.append(token.replace('@NDK@',str(a.ndk.resolve())).replace('@OUT@',str(out)))
 subprocess.run(args,cwd=root,check=True)
 target=out/(name+'.so')
 subprocess.run([a.ndk/'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip','--strip-unneeded','-o',target,out/(name+'.unstripped.so')],check=True)
 results[target.name]=hashlib.sha256(target.read_bytes()).hexdigest()
(out/'relink-result.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
