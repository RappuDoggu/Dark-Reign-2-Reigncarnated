# Reigncarnated 0.1 source and relink kit

This kit replaces the historical menu-only v0.5 recipe. Both native libraries
are rebuildable from these exact debug-stripped application objects and decoder
libraries. No development key, game packs or unstripped native library is included.
Port source and the pinned full FFmpeg n6.1.1 archive accompany these objects.

Linux x86_64, Python3, Android NDK27.2.12479018:

    python3 relink.py --ndk /path/to/ndk --output /private/relinked

The two stripped library SHA256 values must match the release build receipt.
To modify FFmpeg, unpack decoder/ffmpeg-n6.1.1.tar.gz, make your edits and run its
configure/make/install with the flags in build_bink_decoder.sh (invoke configure
directly for modified source; do not weaken the upstream archive checksum).
Then pass --decoder-libs /your/modified/install/lib to relink.py.
For an unmodified decoder rebuild:

    export ANDROID_NDK_HOME=/path/to/ndk
    bash build_bink_decoder.sh "$PWD/decoder" android
    python3 relink.py --ndk "$ANDROID_NDK_HOME" --output /private/relinked --decoder-libs "$PWD/decoder/android/install/lib"

Replace lib/arm64-v8a/libreign_menu.so and libreign_mission.so in unsigned.apk,
storing the libraries uncompressed. Use Android build-tools35.0.0 zipalign -P16
then apksigner with YOUR private key. The port's original signing key is never
part of the kit. A modified app signed by a different key cannot update the
existing installation; export owned data before uninstalling it or change the
package identity when rebuilding Java/manifest from source.

source/ contains matching port source, build instructions and source hashes.
The complete original engine source is fetched separately at the pin in those
instructions; application objects are supplied here for decoder replacement.
See source/docs/SOURCE_PROVENANCE.md and COPYING.LGPLv2.1 for provenance/notices.
